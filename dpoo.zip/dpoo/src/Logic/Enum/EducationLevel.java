package Logic.Enum;

public enum EducationLevel {
    Primary,
    Secondary,
    Higher,
    University
}
