package Logic.Enum;

public enum SolidDisc {
    CD,
    DVD
}
