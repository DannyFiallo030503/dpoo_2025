package Logic.Interface;

public interface PricingStrategy {
    double calculatePrice();
}
